////////////////////////////////////////////
//	Copyright (C) 2010,2011 Advanced Micro Devices, Inc. All Rights Reserved.
////////////////////////////////////////////

#pragma once
#if !defined( CLIENT_H )
#define CLIENT_H

//	Boost headers that we want to use
//	#define BOOST_PROGRAM_OPTIONS_DYN_LINK
#include <boost/program_options.hpp>

#endif
