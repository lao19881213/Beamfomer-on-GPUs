/***********************************************************************
**	Copyright (C) 2010,2011 Advanced Micro Devices, Inc. All Rights Reserved.
***********************************************************************/

/* the configured version and settings for clAmdFft
 */
#define clAmdFftVersionMajor 1
#define clAmdFftVersionMinor 8
#define clAmdFftVersionPatch 291
